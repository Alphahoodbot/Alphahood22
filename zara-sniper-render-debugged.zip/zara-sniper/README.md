# ZARA SNIPER — by 0x Zara

A Telegram-controlled Solana trading bot source project with **live transaction adapters** for Jupiter Swap API V2 and PumpPortal's local transaction API. It uses the owner-only Telegram account ID, a dedicated wallet secret supplied through deployment environment variables, real on-chain balance reads, and transaction signatures. It is not a claim that live trading has been tested with your wallet: provider credentials, deployment, real API responses, and a small controlled test transaction must be verified before increasing funds.

## Live capabilities implemented (not independently mainnet-verified)

- Jupiter Swap API V2 order + execute flow for routed Solana swaps; RPC transaction simulation and RPC signature-status verification are required before a trade is reported confirmed.
- PumpPortal local transaction flow for Pump.fun/available pools; signed locally and sent via your configured Solana RPC.
- New PumpPortal token feed via WebSocket.
- Owner-only Telegram command handlers.
- Manual buy confirmation (`/buy ...`, then `/confirm`) and cancel (`/cancel`).
- Auto-buy toggle, auto/manual buy mode, route selection, take-profit/stop-loss monitoring, manual full-balance sell.
- Real SOL/token account balance reads, signature confirmation checks, SQLite trade log, daily spend cap, per-trade cap, emergency stop.
- Basic DexScreener liquidity/volume checks for Jupiter manual buys.

## Important limits (read before funding)

- **No bot can guarantee profitable trades, buying first, or a successful stop-loss.** Tokens may be malicious, liquidity may vanish, slippage may be extreme, RPC/API providers can fail, and an exit can be impossible.
- DexScreener's market fields are not a security audit. This project does not fully verify mint/freeze authority, holder concentration, token extensions, transfer restrictions, or honeypot behavior.
- PumpPortal `vSolInBondingCurve` is a *virtual reserve* signal, not actual withdrawable liquidity. The new-token auto-buy filter is only a crude first gate.
- TP/SL monitoring depends on DexScreener `priceUsd` data and polling. For tokens without a pair/price feed, automated TP/SL cannot trigger. It is not an exchange-native stop order and may miss fast moves.
- PumpPortal may change API requirements or route names. Jupiter/PumpPortal endpoints and network behavior can change; monitor logs after deploy.
- A transaction may be submitted but not confirmed within the timeout. Check its signature before retrying; don't blindly resubmit and risk duplicate trades.
- This is an initial live-capable implementation, not an audited financial system. Do not use your main wallet. Use a new, low-balance trading wallet and start with the smallest practical amount.
- “Connect existing wallet” here means configuring a dedicated wallet private key as a Render secret. It does **not** implement Phantom in-chat wallet connection or hardware-wallet signing. Never send a private key to the Telegram bot.
- Jupiter route uses current Swap API V2 (`/order` + `/execute`); PumpPortal uses its local transaction API. Jupiter requires an API key for recommended production limits. PumpPortal availability is subject to its service terms.

## Telegram commands

- `/start`, `/help`, `/wallet`
- `/discover`, `/price <mint-or-symbol>`
- `/buy <mint> [SOL] [jupiter|pumpfun]` — prepares a real buy, requires `/confirm`
- `/confirm`, `/cancel`
- `/sell <mint> [jupiter|pumpfun]` — attempts to sell the full actual balance of the mint
- `/portfolio`, `/history`, `/settings`
- `/setbuy <SOL>`, `/settp <percent>`, `/setsl <percent>`, `/setslippage <bps>`, `/setmax <SOL>`
- `/engine auto|jupiter|pumpfun`
- `/mode manual|auto`
- `/sellmode auto|manual`
- `/auto on|off`
- `/stop`, `/resume`

Auto-buy is off by default. For Pump.fun auto-sniping, choose `/mode auto`, select the engine if needed, review the caps with `/settings`, then explicitly run `/auto on`. Auto-buy can spend real SOL. `/stop` disables auto-buy and pauses auto TP/SL checks; it cannot cancel an already-submitted blockchain transaction.

## Create a dedicated wallet

On a private local terminal (Termux or a trusted computer), install dependencies and run:

```bash
pip install -r requirements.txt
python create_wallet.py
```

The script prints a private key once. Save it securely and set it as `SOLANA_PRIVATE_KEY` in your deployment environment. **Never put the key in GitHub, commit `.env`, paste it into Telegram, or share it with anyone.** You can instead use a separate existing trading wallet by configuring its secret, but a dedicated low-balance wallet is strongly recommended.

## Required deployment environment variables

Use `.env.example` as a checklist. Set:

- `TELEGRAM_BOT_TOKEN` — from the official @BotFather chat.
- `OWNER_ID` — your numeric Telegram user ID.
- `TRADING_MODE=live`.
- `SOLANA_RPC_URL` — a reliable Solana mainnet RPC URL from a provider.
- `SOLANA_PRIVATE_KEY` — dedicated trading wallet key.
- `JUPITER_API_KEY` — production key from Jupiter's developer portal.
- `MAX_POSITION_SOL` and `MAX_DAILY_SPEND_SOL` — very small caps to begin with.

Keep `AUTO_BUY_ENABLED_AT_START=false`; auto-buy state is off in the database by default. Do not add secrets to repository files.

## Deploy to Botkeep or another persistent worker

1. Upload the entire project directory to your private `zara-sniper` GitHub repository.
2. In Render, create a **Background Worker** from that repository.
3. Build command: `pip install -r requirements.txt`.
4. Start command: `python bot.py`.
5. Add environment variables listed above in Render's Environment panel.
6. Attach a persistent disk mounted at `/opt/render/project/src/data` for SQLite state. If your Render plan does not support persistent disks, use a persistent external database before relying on settings/trade history.
7. Deploy and inspect logs. Start with a tiny amount and manual buy mode; do not turn on auto-buy until a real small buy and full sell have both been verified.

## Release status

This is deployable source code, not a pre-connected hosted service. It cannot trade until you add your own Telegram token, owner ID, mainnet RPC, Jupiter API key, and dedicated wallet secret in Render. No live mainnet trade has been performed by the authoring environment. First deployment must be treated as a controlled integration test.

## Local syntax checks

```bash
python -m compileall bot.py zara_sniper create_wallet.py
pytest -q
```


## Botkeep deployment

Use `python bot.py` as the start command (the repository entry point is `bot.py`).
Install dependencies with `pip install -r requirements.txt`. Set `TELEGRAM_BOT_TOKEN`
and `OWNER_ID` in Botkeep's environment-variable settings, along with the wallet/RPC
variables described above. Do not put secrets in source code or commit a populated
`.env` file. The app stores settings, positions, and history in SQLite at
`DATABASE_PATH`; configure a persistent volume or external database if Botkeep's
runtime filesystem is ephemeral. Confirm Botkeep supports a continuously running
worker process and persistent storage before relying on automated trading.


## Safety notes added during repository repair

- Transaction payloads are RPC-simulated before signing; simulation errors or unavailable simulation fail closed. RPC signature status is checked after submission (including Jupiter execution responses).
- Buy execution is serialized to reduce daily-cap race conditions, and duplicate buys for an already-tracked mint are blocked pending reconciliation.
- `/setslippage <bps>` is available, but cannot exceed the configured `MAX_SLIPPAGE_BPS` deployment cap.
- These controls reduce risk but are not an audit. API contracts can change; live mainnet execution and Botkeep storage/process behavior still need deployment verification.


## Render deployment: important Free-plan limitation

`render.yaml` is the persistent **Background Worker** deployment. Render Free does not provide free background workers or persistent disks, so this blueprint requires a paid worker/disk for dependable 24/7 token monitoring, auto-sniping, and take-profit/stop-loss checks. Build command: `pip install -r requirements.txt`; start command: `python bot.py`.

`render-free.yaml` is a separate **Free web service** blueprint for startup and Telegram-command testing only. It uses Telegram webhooks and `TRADING_MODE=paper`. Render Free services can sleep and have ephemeral storage, so this mode is not suitable for real-money trades, automated sniping, or persistent position monitoring. Do not change it to live mode. To use it, choose `render-free.yaml` as the Blueprint file when creating a Render Blueprint.

`TELEGRAM_MODE` supports `polling` (persistent worker) or `webhook` (web service). Webhook mode requires `RENDER_EXTERNAL_URL` (automatically supplied by Render) or `WEBHOOK_URL`, plus the `webhooks` optional dependency.
